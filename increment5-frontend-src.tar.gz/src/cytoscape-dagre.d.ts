declare module "cytoscape-dagre";
